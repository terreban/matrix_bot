import simplematrixbotlib as botlib
import requests as req
from agentmail import AgentMail
import asyncio
import json
import httpx2
from httpx_sse import connect_sse
import os.path
import base64
import smtplib

import menu # import the module

# matil.tm related variables
url = "https://api.mail.tm/domains"
domains = []

# Create an SMTP object
smtpobj = smtplib.SMTP();



# Sms number verification
instruction_sms = "**balance** - to verify your balance"
api_key_number = "03898b3b10591550823d639252ff0850"



config = botlib.Config()
config.encryption_enabled = True
config.emoji_verify = True
config.ignore_unverified_devices = True
prefix = "!"
creds = botlib.Creds("https://matrix.org", "email_bot", "0TW5Sx7MUEiw")
bot = botlib.Bot(creds, config)
main_flow = 0
ids =[[], None]
credentials = [None, None, None]
client = AgentMail(api_key="am_us_f6b1b0340b0c7fcada5623f3fea407f279f68c750285cc5fc714ef9d5cfcf8dd")






# Create a temporary new email address
def spawn_email():
    resp = json.loads(req.get(url).text)
    for items in resp['hydra:member']:
        domains = items['domain']
        global main_flow
        main_flow = 1 # redirect flow to ask for address and password
        return domains


# SMTP sending
def smtp_send(text,to,subject):
        smtpobj.ehlo()
        smtpobj.starttls() # Secure the connection
        smtpobj.login("","")






# Account creation
def spawn_account(address, passw):
    try:
        resp = json.loads(req.post("https://api.mail.tm/accounts", headers={"Content-Type": "application/json"}, json={"address":address, "password":"12345"}).text)
        print(resp)
        if resp['@type'] == "Account":
            # Write token into storage file

            token = json.loads(req.post("https://api.mail.tm/token", headers={"Content-Type":"application/json"}, json={"address":address, "password":passw}).text)
            new_record = {"token": token['token'], "address": address,"account":token['id'] }
            print("new record: ", new_record)
            with open("token", "r") as fd:
                try:
                    inner = json.load(fd)
                    print("INnner", inner)
                    inner.append(new_record)
                    print("new_val", inner)
                except:
                    print("error")

            fd = open("token", "w+")
            try:
                json.dump(inner,fd)
            except:
                json.dump([new_record], fd)
            fd.close()
            return [200, new_record['token'], token['id']]
        else:
            return [resp['status'], resp['violations'][0]['message']]
    except:
        return ["0","unknown"]

# Fetch all existing mails
def fetch(token):
    try:
        global messages
        resp = json.loads(req.get("https://api.mail.tm/messages", headers={"Authorization": f"Bearer {token}"}).text)
        print("\n\nMessage", resp)
        # list every mail
        index =0
        ids =[]
        messages = []
        for arg  in resp['hydra:member']:
            index+=1
            new_str = arg['subject'] + " from " + arg['from']['address'] + f" [{index}]"
            ids.append(arg['id'])
            messages.append(new_str)
        print("\nall messages:", messages)
        return [resp['hydra:totalItems'],messages,ids,token ]
    except:
        print("error message")


# Listener funciton
async def listen_mail(resp, room_id):
    async with httpx2.AsyncClient(timeout=None) as client:
        async with client.sse("https://mercure.mail.tm/.well-known/mercure", params = {"topic": f"/accounts/{resp[2]}"}, headers={"Authorization": f"Bearer {resp[1]}"}) as event_source:
            async for sse in event_source:
                data = json.loads(sse.data)
                #print("result: ", data['from'])
                if data['@type'] == "Message":
                    print("result: ", data['from']['address'])
                    await bot.api.send_text_message(room_id, "You have received a new message from "+data['from']['address'])

# read all existing emails
def read_files():
    fd = open("token", "r")
    data = json.load(fd)
    try:
        accounts = []
        print("\n\ndata", data)
        fd.close()
        for i in data:
            accounts.append(i['address'])
        return [1, accounts]
    except:
        return [0]


# Find token based on address
def find_token(address):
    try:
        fd = open("token", "r")
        parse = json.load(fd)
        for i in parse:
            if i['address'] == address:
                return [None, i['token'],i['account']]
    except:
        return [202]

# Obtain mail's content
def get_content(id, token):
    resp = json.loads(req.get(f"https://api.mail.tm/messages/{id}", params={"id":id},  headers={"Authorization": f"Bearer {token}"}).text)
    try:
        return [resp['text']]
    except:
        return [0]

# Send email implementation
def send_mail(text, recever, subject):
    client.inboxes.messages.send(
        "hikita-8550@agentmail.to",
        to=[recever],
        subject=subject,
        text=text,
    )

# Delete an account
def delete_account(id, token):
    res = req.delete(f"https://api.mail.tm/accounts/{id}", headers={"Authorization": f"Bearer {token}"})
    print("\n\nresp: ", res.text)
    try:
        new_content = []
        fd = open("token", "r")
        parse = json.load(fd)
        fd.close()
        for i in parse:
            if i['account'] != id:
                new_content.append(i)
        with open("token", "w+") as fd:
            json.dump(new_content, fd)
    except:
        print("Error")


# Balance viewer
def get_balance():
    repl = json.loads(req.get(f"https://api.buynumber.io/v1/account?api_key={api_key_number}&action=getBalance").text)
    return repl['data']['balance']


# Get sms services
def get_services_sms(service: str):
    repl = json.loads(req.get(f"https://api.buynumber.io/v1/activation-numbers?api_key={api_key_number}&action=getServices").text)
    for serv in repl['data']:
        if serv['name'].upper() == service.upper():
            repl = json.loads(req.get(f"https://api.buynumber.io/v1/activation-numbers?api_key={api_key_number}&action=getTopCountriesByService&service={serv['code']}").text)
            for country in repl['data']:
                print(f"country: {country['country']}, price: {country['price']} ")





# command functino implementation
@bot.listener.on_message_event
async def echo(room, message):
        global main_flow, ids, credentials
        match = botlib.MessageMatch(room, message, bot, prefix)
        await state.get_call(room, message, match, bot) # Call the callback funcitno

        if main_flow == 0:
            if match.is_not_from_this_bot() and match.prefix() and match.command("new"):
                await bot.api.send_text_message(room.room_id, "Available domains:\n"+ spawn_email())
                await bot.api.send_text_message(room.room_id, "Send a desirable address (with domain)")
            elif match.is_not_from_this_bot() and match.prefix() and match.command("all"):
                try:
                    file = read_files()
                    response = "There are no emails" if file[0] == 0 else "Emails:\n"+"\n".join(file[1])
                    await bot.api.send_text_message(room.room_id, response)
                except:
                    await bot.api.send_text_message(room.room_id, "No emails")
            elif match.is_not_from_this_bot() and match.prefix() and match.command("receive"):
                await bot.api.send_text_message(room.room_id, "Send an address of the email")
                main_flow = 2
            elif match.is_not_from_this_bot() and match.prefix() and match.command("inbox"):
                await bot.api.send_text_message(room.room_id, "Specify the email for which you would like to see the inbox")
                main_flow = 3
            elif match.is_not_from_this_bot() and match.prefix() and match.command("read"):
                await bot.api.send_text_message(room.room_id, "Specify the email for which you would like to read email")
                main_flow = 4
            elif match.is_not_from_this_bot() and match.prefix() and match.command("send"):
                await bot.api.send_text_message(room.room_id, "Specify the text content")
                main_flow = 6
            elif match.is_not_from_this_bot() and match.prefix() and match.command("sms"):
                await bot.api.send_text_message(room.room_id, instruction_sms)
                main_flow = 10
            elif match.is_not_from_this_bot() and match.prefix() and match.command("delete"):
                await bot.api.send_text_message(room.room_id, "Enter an account")
                main_flow = 9
            elif match.is_not_from_this_bot():
                    await bot.api.send_markdown_message(room.room_id, "new email - to create one-time temporary email and receive email\n" +
                        "all - to see existing emails\nreceive - to receive new messages from existing emails\ninbox -  to check the entire inbox\n"+
                        "read - to read a specific email\n **send** - to send email \n **delete** - to delete existing email address")

        elif main_flow == 1:
            if match.is_not_from_this_bot():
                resp = spawn_account(message.body, "12345")
                match resp[0]:
                    case 200:
                        await bot.api.send_text_message(room.room_id, "Successfully created address, listener is starting...")
                        asyncio.create_task(listen_mail(resp, room.room_id))
                    case _:
                        await bot.api.send_text_message(room.room_id, "Error: "+str(resp[0])+"\nmessage: "+resp[1])

                main_flow = 0 # Switch to main loop
        elif main_flow == 2:
            if match.is_not_from_this_bot():
                try:
                    resp = find_token(message.body)
                    print("Found: ", resp)
                    asyncio.create_task(listen_mail(resp, room.room_id))
                    main_flow = 0
                except:
                    await bot.api.send_text_message(room.room_id, "Unknown error: check your spelling ")
                    main_flow = 0
        elif main_flow == 3:
            if match.is_not_from_this_bot():
                try:
                    token = find_token(message.body)[1]
                    result = fetch(token)
                    await bot.api.send_markdown_message(room.room_id, f"### Yout have total: {result[0]} messages")
                    items = "\n".join(f"* {item}" for item in result[1])
                    await bot.api.send_markdown_message(room.room_id,f"### The mesages:\n{items}")
                    main_flow = 0
                except:
                    await bot.api.send_text_message(room.room_id, "Unknown error: check your spelling ")
                    main_flow = 0
        elif main_flow == 4:
            if match.is_not_from_this_bot():
                try:
                    token = find_token(message.body)[1]
                    result = fetch(token)
                    ids[0] = result[2]
                    ids[1] = result[3]
                    await bot.api.send_markdown_message(room.room_id, f"### Yout have total: {result[0]} messages")
                    items = "\n".join(f"* {item}" for item in result[1])
                    await bot.api.send_markdown_message(room.room_id,f"### The mesages:\n{items}")
                    await bot.api.send_text_message(room.room_id, "Print the number of the email to read or 'exit' to return")
                    main_flow = 5
                except:
                    await bot.api.send_text_message(room.room_id, "Unknown error: check your spelling ")
                    main_flow = 0
        elif main_flow == 5:
            if match.is_not_from_this_bot():
                try:
                    if message.body == "exit":
                        await bot.api.send_text_message(room.room_id, "Your're back")
                        main_flow = 0
                    else:
                        print("IDS: ", ids)
                        print("Current number = ", int(message.body))
                        await bot.api.send_markdown_message(room.room_id, "### Content: \n" + f"> {get_content(ids[0][int(message.body)-1], ids[1])[0]}")
                        main_flow = 0
                except:
                    await bot.api.send_text_message(room.room_id, "Unknown error: check your spelling ")
                    main_flow = 0
        elif main_flow == 6:
            if match.is_not_from_this_bot():
                    credentials[0] = message.body
                    await bot.api.send_text_message(room.room_id, "Enter the receiver")
                    main_flow = 7
        elif main_flow == 7:
            if match.is_not_from_this_bot():
                    credentials[1] = message.body
                    await bot.api.send_text_message(room.room_id, "Enter the subject")
                    main_flow = 8
        elif main_flow == 8:
            if match.is_not_from_this_bot():
                try:
                    credentials[2] = message.body
                    send_mail(credentials[0],credentials[1],credentials[2])
                    await bot.api.send_text_message(room.room_id, "Successfully sent")
                    main_flow = 0
                except:
                    await bot.api.send_text_message(room.room_id, "Unknown error: check your spelling ")
                    main_flow = 0
        elif main_flow == 9:
            if match.is_not_from_this_bot():
                try:
                    delete_account(find_token(message.body)[2],find_token(message.body)[1])
                    await bot.api.send_text_message(room.room_id, f"{message.body} was deleted")
                except:
                    await bot.api.send_text_message(room.room_id, "Unknown error: check your spelling ")
                main_flow = 0
        elif main_flow == 10:
            if match.is_not_from_this_bot() and match.prefix() and match.command("balance"):
                try:
                    balance = get_balance()
                    await bot.api.send_text_message(room.room_id, f"Your current balance: {balance}")
                except:
                    await bot.api.send_text_message(room.room_id, "Unknown error: check your spelling ")


get_services_sms("telegram")
bot.run()
