import simplematrixbotlib as botlib


# Default system state
positoin = 0


# Implement callback
async def get_call(room, message, match: botlib.MessageMatch, bot: botlib.Bot):
    global positoin
    if positoin == 0:
            # 'new' command
            if match.is_not_from_this_bot() and match.prefix() and match.command("new"):
                await bot.api.send_text_message(room.room_id, "Available domains:\n"+ spawn_email())
                await bot.api.send_text_message(room.room_id, "Send a desirable address (with domain)")

            elif match.is_not_from_this_bot() and match.prefix() and match.command("receive"):
                await bot.api.send_text_message(room.room_id, "Send an address of the email")
                positoin = 2
            elif match.is_not_from_this_bot() and match.prefix() and match.command("inbox"):
                await bot.api.send_text_message(room.room_id, "Specify the email for which you would like to see the inbox")
                positoin = 3
            elif match.is_not_from_this_bot() and match.prefix() and match.command("read"):
                await bot.api.send_text_message(room.room_id, "Specify the email for which you would like to read email")
                positoin = 4
            elif match.is_not_from_this_bot() and match.prefix() and match.command("send"):
                await bot.api.send_text_message(room.room_id, "Specify the text content")
                positoin = 6
            elif match.is_not_from_this_bot() and match.prefix() and match.command("sms"):
                await bot.api.send_text_message(room.room_id, instruction_sms)
                positoin = 10
            elif match.is_not_from_this_bot() and match.prefix() and match.command("delete"):
                await bot.api.send_text_message(room.room_id, "Enter an account")
                positoin = 9
            elif match.is_not_from_this_bot():
                    await bot.api.send_markdown_message(room.room_id, "new email - to create one-time temporary email and receive email\n" +
                        "all - to see existing emails\nreceive - to receive new messages from existing emails\ninbox -  to check the entire inbox\n"+
                        "read - to read a specific email\n **send** - to send email \n **delete** - to delete existing email address")
